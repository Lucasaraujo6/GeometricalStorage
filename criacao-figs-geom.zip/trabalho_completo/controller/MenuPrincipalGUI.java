package trabalho_completo.controller;

public class MenuPrincipalGUI {

}
