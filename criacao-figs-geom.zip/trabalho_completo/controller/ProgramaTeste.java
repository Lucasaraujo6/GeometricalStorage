package trabalho_completo.controller;



public class ProgramaTeste {

    public static void main(String[] args) {
        LucasPaint prog = new LucasPaint();
        prog.mostrarMenu();
    }
}

