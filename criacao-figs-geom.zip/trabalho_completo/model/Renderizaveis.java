package trabalho_completo.model;

import java.io.Serializable;

public class Renderizaveis implements Serializable {

    public double getPerimetro(){
        return -1;
    }
    public double getArea(){
        return -1;
    }
}
